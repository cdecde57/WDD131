#!/bin/bash

# Wait for Redis to be available
until redis-cli -h redis-external -p 1111 ping 2>/dev/null | grep -q PONG; do
  echo "Waiting for Redis..."
  sleep 1
done

# Change to app directory
cd /home/app/saintcon-appsec-harness/app

# Ensure database directory exists and has correct permissions
echo "Ensuring database directory exists..."
mkdir -p /home/app/saintcon-appsec-harness/app/data/db

# Remove any existing db.sqlite3 if it's a directory (common mistake)
if [ -d /home/app/saintcon-appsec-harness/app/data/db/db.sqlite3 ]; then
    echo "Removing incorrect db.sqlite3 directory..."
    rm -rf /home/app/saintcon-appsec-harness/app/data/db/db.sqlite3
fi

# Create database file if it doesn't exist
if [ ! -f /home/app/saintcon-appsec-harness/app/data/db/db.sqlite3 ]; then
    echo "Creating database file..."
    touch /home/app/saintcon-appsec-harness/app/data/db/db.sqlite3
fi

chown -R app:app /home/app/saintcon-appsec-harness/app/data/db

# Set up database, migrations, and challenges gracefully
echo "Setting up database and challenges..."
/home/app/saintcon-appsec-harness/app/venv/bin/python manage.py setup_database

# Collect static files
echo "Collecting static files..."
/home/app/saintcon-appsec-harness/app/venv/bin/python manage.py collectstatic --noinput

# Fix static files ownership for RQ worker
echo "Fixing static files permissions..."
chown -R app:app /home/app/saintcon-appsec-harness/app/staticfiles/

# Ensure log directory permissions are correct
echo "Fixing log directory permissions..."
mkdir -p /var/log/appsecchallenge
chown -R app:app /var/log/appsecchallenge

echo "Starting supervisord..."
exec /usr/bin/supervisord -c /etc/supervisor/conf.d/supervisord.conf