#!/bin/bash
# Create Django superuser for SAINTCON AppSec Harness

echo "=== Creating Django Admin User ==="
echo ""

# Check if container is running
if ! docker compose ps | grep -q "app.*Up"; then
    echo "❌ Error: The app container is not running."
    echo "Please start it first with: docker-compose up -d"
    exit 1
fi

# Ensure migrations are up to date
echo "Checking and applying any pending migrations..."
docker compose exec app /home/app/saintcon-appsec-harness/app/venv/bin/python manage.py migrate

echo ""
echo "Creating superuser in the Django application..."
echo ""
echo "Default credentials: admin / admin"
echo "You can change these in the Django admin interface after logging in."
echo ""

# Create superuser using Django management command
docker compose exec app /home/app/saintcon-appsec-harness/app/venv/bin/python manage.py shell -c "
from django.contrib.auth import get_user_model
User = get_user_model()

# Remove existing admin user if it exists
try:
    if User.objects.filter(username='admin').exists():
        User.objects.filter(username='admin').delete()
        print('Removed existing admin user')
except Exception as e:
    print(f'Note: Could not remove existing user: {e}')

# Create new superuser
try:
    user = User.objects.create_superuser('admin', 'admin@saintcon.local', 'admin')
    print('✅ Superuser created successfully!')
    print('   Username: admin')
    print('   Password: admin')
    print('   Email: admin@saintcon.local')
except Exception as e:
    print(f'❌ Error creating superuser: {e}')
    print('This might mean the admin user already exists.')
    print('Try logging in with admin/admin or reset the container.')
"

echo ""
echo "=== Admin User Created ==="
echo ""
echo "You can now:"
echo "1. Visit http://localhost:8888/admin/ to access the Django admin"
echo "2. Log in with username: admin, password: admin"
echo "3. Change the admin password in the admin interface"
echo ""
echo "💡 Tip: You can also create regular users through the admin interface"
echo "    or by registering through the main application interface."