# Logging Configuration

## Log Files Location

All logs are centralized in `/var/log/appsecchallenge/` (mapped to `./data/logs/` on host):

### Django Application Logs
- `django.log` - General Django application logs
- `rq.log` - RQ (Redis Queue) worker logs  
- `testharness.log` - Test execution and scoring logs (DEBUG level)

### Service Logs
- `supervisor.log` - Supervisor process manager logs
- `nginx-access.log` - Nginx access logs
- `nginx-error.log` - Nginx error logs  
- `nginx-stdout.log` - Nginx stdout (from supervisor)
- `nginx-stderr.log` - Nginx stderr (from supervisor)
- `uwsgi.log` - uWSGI application server logs
- `uwsgi-stdout.log` - uWSGI stdout (from supervisor)
- `uwsgi-stderr.log` - uWSGI stderr (from supervisor) 
- `rq-worker-stdout.log` - RQ worker stdout (from supervisor)
- `rq-worker-stderr.log` - RQ worker stderr (from supervisor)

## Log Rotation

### Automatic Rotation
- **Django logs**: 10MB files, 5 backups via Python RotatingFileHandler
- **uWSGI logs**: 10MB rotation built into uWSGI config
- **Supervisor logs**: 10MB files, 5 backups via supervisor config
- **System logs**: Daily rotation via logrotate, 14 days retention

### Manual Log Rotation
```bash
# Force log rotation
docker exec <container_id> logrotate -f /etc/logrotate.d/appsecchallenge
```

## Log Levels

### Development
- Django: DEBUG
- RQ: INFO
- Test Harness: DEBUG (captures all test execution details)

### Production  
- Django: INFO
- RQ: INFO
- Test Harness: DEBUG (still DEBUG for troubleshooting test issues)

## Viewing Logs

### Real-time monitoring
```bash
# All logs
tail -f data/logs/*.log

# Specific service
tail -f data/logs/django.log
tail -f data/logs/testharness.log
```

### Inside container
```bash
# Enter container
docker exec -it <container_id> /bin/bash

# View logs
tail -f /var/log/appsecchallenge/django.log
supervisorctl tail -f nginx stderr
```

## Log Analysis

### Key Log Files for Debugging
1. **Test Issues**: `testharness.log` - Contains detailed test execution
2. **Web Issues**: `django.log` + `nginx-error.log` + `uwsgi.log`
3. **Background Jobs**: `rq.log` + `rq-worker-stdout.log`
4. **Service Issues**: `supervisor.log`

### Common Log Patterns
```bash
# Test execution flow
grep "initializing job" data/logs/testharness.log

# Failed submissions
grep "Docker run failed" data/logs/testharness.log

# Web errors
grep "ERROR" data/logs/django.log data/logs/nginx-error.log

# Queue status
grep "worker" data/logs/rq.log
```