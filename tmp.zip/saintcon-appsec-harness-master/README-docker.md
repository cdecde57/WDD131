# Docker Setup for SAINTCON AppSec Harness

## Architecture

The system uses **Docker socket mounting** (not Docker-in-Docker) for better security and performance:

- Main container runs Django app, nginx, and RQ workers
- Mounts host Docker socket to spawn test containers
- Uses external Redis service
- Shared volumes for file exchange with test containers

## Development vs Production

### Development Setup
```bash
# Initialize data directories
./init-data-dirs.sh

# Run in development mode (default)
docker-compose up --build
```

**Alternative manual setup:**
```bash
# Create data directories manually
mkdir -p data/{submissions,test-results,docker-share,logs,db,static}
chmod 777 data/db

# Run in development mode
docker-compose up --build
```

### Production Setup
```bash
# Create production data directories
sudo mkdir -p /home/app/data/{submissions,test-results,docker-share,logs,db,static}

# Ensure SSL certificates exist
sudo certbot certonly --nginx -d appsec.saintcon.community

# Run in production mode
docker-compose -f docker-compose.prod.yml up --build -d
```

## Environment Configuration

Set `ENVIRONMENT` variable to control configuration:

**Development (default):**
- `ENVIRONMENT=development`
- Debug mode enabled
- Dev nginx config (no SSL)
- Allows all hosts

**Production:**
- `ENVIRONMENT=production`
- Debug mode disabled
- Production nginx config (SSL required)
- Restricted to configured host
- Security headers enabled

## How Test Execution Works

1. User submits code via web interface (port 80)
2. Django RQ worker picks up test job
3. Worker calls `run-docker.sh` which:
   - Copies files to shared volume (`data/docker-share`)
   - Spawns test containers using host Docker daemon
   - Test containers join `appnetwork` to communicate
   - Results written back to shared volume
4. Django processes test results and updates scores

## Network Architecture

- `appnetwork`: Bridge network for all containers
- Main app and test containers can communicate
- External Redis on port 1111
- Web interface on port 80

## Volumes

- `data/submissions`: User-submitted files
- `data/test-results`: JSON test results
- `data/docker-share`: Temporary file exchange
- `data/logs`: Application logs
- `data/db`: SQLite database persistence

## Security Notes

- App user has limited sudo access for Docker operations
- Docker socket mounting is safer than DinD but still requires trust
- Test containers are ephemeral and cleaned up after each run