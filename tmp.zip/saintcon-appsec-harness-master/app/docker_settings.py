# Docker-specific settings override
import os
from appsecchallenge.settings import *

# Environment-based configuration
ENVIRONMENT = os.environ.get('ENVIRONMENT', 'development')
IS_PRODUCTION = ENVIRONMENT == 'production'

# Use external Redis service
RQ_QUEUES = {
    'default': {
        'HOST': 'redis-external',
        'PORT': 1111,
        'DB': 0,
        'DEFAULT_TIMEOUT': 360,
    },
}

# Environment-specific settings
if IS_PRODUCTION:
    DEBUG = False
    ALLOWED_HOSTS = [os.environ.get('ALLOWED_HOST', 'appsec.saintcon.community')]
    SECURE_SSL_REDIRECT = True
    SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
else:
    DEBUG = True
    ALLOWED_HOSTS = ["*"]

# Ensure static files work in container
STATIC_ROOT = '/home/app/saintcon-appsec-harness/app/staticfiles/'

# Use mounted database directory
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': '/home/app/saintcon-appsec-harness/app/data/db/db.sqlite3',
    }
}

# Enhanced logging configuration for Docker
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '[{asctime}] {levelname} {name} {process:d} {thread:d} {message}',
            'style': '{',
        },
        'simple': {
            'format': '[{asctime}] {levelname} {name}: {message}',
            'style': '{',
        },
    },
    'handlers': {
        'console': {
            'level': 'INFO',
            'class': 'logging.StreamHandler',
            'formatter': 'simple',
        },
        'file_django': {
            'level': 'INFO',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': '/var/log/appsecchallenge/django.log',
            'maxBytes': 10485760,  # 10MB
            'backupCount': 5,
            'formatter': 'verbose',
        },
        'file_rq': {
            'level': 'INFO', 
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': '/var/log/appsecchallenge/rq.log',
            'maxBytes': 10485760,  # 10MB
            'backupCount': 5,
            'formatter': 'verbose',
        },
        'file_testharness': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler', 
            'filename': '/var/log/appsecchallenge/testharness.log',
            'maxBytes': 10485760,  # 10MB
            'backupCount': 5,
            'formatter': 'verbose',
        },
    },
    'loggers': {
        'django': {
            'handlers': ['console', 'file_django'],
            'level': 'INFO',
            'propagate': False,
        },
        'rq': {
            'handlers': ['console', 'file_rq'],
            'level': 'INFO',
            'propagate': False,
        },
        'main.testharness': {
            'handlers': ['console', 'file_testharness'],
            'level': 'DEBUG',
            'propagate': False,
        },
        'main': {
            'handlers': ['console', 'file_django'],
            'level': 'INFO',
            'propagate': False,
        },
    },
    'root': {
        'handlers': ['console', 'file_django'],
        'level': 'INFO' if IS_PRODUCTION else 'DEBUG',
    },
}