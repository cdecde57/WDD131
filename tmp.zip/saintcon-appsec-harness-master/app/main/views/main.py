from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect, HttpResponseNotFound
from main.models import Submission, Status, UnitTest, Challenge, UserChallenge, UserFlag
from main.testcases import get_challenge_config
from main.testharness import run
from uuid import uuid4
from appsecchallenge import settings
import logging
import django_rq
import os
from datetime import datetime, timezone
from main.util import get_flag, sha, UploadFileForm
from main.util import get_scores
from dateutil import tz

# Use Django RQ's default connection which respects Django settings
queue = django_rq.get_queue('default')
score_cache = (None, None)

logger = logging.getLogger(__name__)


def index(request):
    logger.info("index was hit")
    return HttpResponseRedirect("/challenge")


def scoreboard(request):
    global score_cache
    time, scores = score_cache
    if not time or (datetime.now(timezone.utc) - time).total_seconds() > settings.CACHE_TTL:
        scores = get_scores()
        score_cache = datetime.now(timezone.utc), scores
    return render(request, "scoreboard.html", {"p": "scoreboard", "submissions": scores})


def scoreboard_2(request):
    if request.user.username != "sketrik":
        return HttpResponseRedirect("/")
    global score_cache
    time, scores = score_cache
    if not time or (datetime.now(timezone.utc) - time).total_seconds() > settings.CACHE_TTL:
        scores = get_scores()
        score_cache = datetime.now(timezone.utc), scores
    return render(request, "scoreboard-view.html", {"p": "scoreboard", "submissions": scores})


def challenge(request):
    # Show all active challenges
    challenges = Challenge.objects.filter(active=True).order_by('created_date')
    
    # Get unlocked challenges for authenticated users
    unlocked_challenge_ids = set()
    if request.user.is_authenticated:
        unlocked_challenge_ids = set(UserChallenge.objects.filter(
            user=request.user, unlocked=True
        ).values_list('challenge_id', flat=True))
    
    # Add unlock status to challenges
    challenges_with_status = []
    for challenge in challenges:
        challenges_with_status.append({
            'challenge': challenge,
            'unlocked': challenge.id in unlocked_challenge_ids or not request.user.is_authenticated
        })
    
    selected_challenge_id = request.GET.get('challenge_id')
    selected_challenge = None
    selected_challenge_unlocked = False
    if selected_challenge_id:
        try:
            challenge = Challenge.objects.get(id=selected_challenge_id, active=True)
            selected_challenge = challenge
            selected_challenge_unlocked = challenge.id in unlocked_challenge_ids or not request.user.is_authenticated
        except Challenge.DoesNotExist:
            pass
    
    return render(request, "challenge.html", {
        "p": "challenge",
        "challenges_with_status": challenges_with_status,
        "selected_challenge": selected_challenge,
        "selected_challenge_unlocked": selected_challenge_unlocked
    })


@login_required
def submit(request):
    # uncomment when closing submissions
    # return HttpResponseRedirect("/challenge?msg=12")
    
    # Get challenge from form data
    challenge_id = request.POST.get('challenge_id')
    if not challenge_id:
        return HttpResponseRedirect("/challenge?msg=10")  # Missing challenge selection
    
    try:
        challenge = Challenge.objects.get(id=challenge_id, active=True)
        # Check if user has unlocked this challenge
        if not UserChallenge.objects.filter(user=request.user, challenge=challenge, unlocked=True).exists():
            return HttpResponseRedirect("/challenge?msg=13")  # Challenge not unlocked
    except Challenge.DoesNotExist:
        return HttpResponseRedirect("/challenge?msg=10")  # Invalid challenge
    
    most_recent_submission = Submission.objects.filter(user=request.user, challenge=challenge, score__gt=-1).order_by("-created").first()
    if most_recent_submission and not settings.DEBUG:
        diff = int((datetime.now(timezone.utc) - most_recent_submission.created).total_seconds())
        if diff < settings.SECONDS_BETWEEN_SUBMISSIONS:
            return HttpResponseRedirect(f"/challenge?challenge_id={challenge_id}&msg=5&mins=" + str(diff // 60))

    # save file
    form = UploadFileForm(request.POST, request.FILES)
    if not form.is_valid():
        return HttpResponseRedirect(f"/challenge?challenge_id={challenge_id}&msg=9")
    if len(request.FILES) == 0:
        return HttpResponseRedirect(f"/challenge?challenge_id={challenge_id}&msg=11")

    job_id = str(uuid4())
    f = request.FILES["file"]
    if f.size > settings.MAX_FILE_SIZE:
        return HttpResponseRedirect(f"/challenge?challenge_id={challenge_id}&msg=7")

    fname = os.path.join(settings.SUBMISSION_PATH, job_id)
    if not os.path.exists(settings.SUBMISSION_PATH):
        os.makedirs(settings.SUBMISSION_PATH)
    with open(fname, 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)

    # check for duplicate hash within the same challenge
    filehash = sha(fname)
    duplicate_submission = Submission.objects.filter(filehash=filehash, challenge=challenge).first()
    if duplicate_submission and not settings.DEBUG and not duplicate_submission.status == Status.FAILED.value:
        if duplicate_submission.user == request.user:
            return HttpResponseRedirect(f"/challenge?challenge_id={challenge_id}&msg=6")

    # submit job
    submission = Submission(user=request.user, challenge=challenge, filehash=filehash, job_id=job_id)
    submission.save()
    result = queue.enqueue(run, job_id)
    return HttpResponseRedirect(f"/challenge?challenge_id={challenge_id}&msg=8")


def submission(request, submission_id):
    submission = Submission.objects.filter(user=request.user, job_id=submission_id).first()
    if not submission:
        return HttpResponseNotFound()

    # Get challenge-specific configuration
    challenge_id = submission.challenge.id if submission.challenge else None
    config = get_challenge_config(challenge_id)

    tests = UnitTest.objects.filter(submission=submission).all()
    test_results = []
    for test in tests:
        test_results.append({
            "name": test.test_id,
            "result": test.passed
        })

    # Get user flags
    user_flag = UserFlag.objects.filter(user=request.user).first()
    
    return render(request, "submission.html", {
        "test_results": sorted(test_results, key=lambda x: x['name']),
        "submission": submission, 
        "date": submission.created.astimezone(tz.tzlocal()),
        "flag1": get_flag(1, submission.filehash),
        "flag2": get_flag(2, submission.filehash) if user_flag and user_flag.flag2 else None,
        "flag3": get_flag(3, submission.filehash) if user_flag and user_flag.flag3 else None
    })
