from django.shortcuts import render
from django.http import HttpResponseBadRequest, HttpResponseRedirect
from django.contrib.auth import authenticate, login as django_login, logout as django_logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from datetime import datetime, timezone
from appsecchallenge import settings
from main.util import get_user_scores, get_flag, get_global_flags

user_score_cache = {}


def login(request):
    if request.method == "GET":
        return render(request, "login.html", {})
    elif request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(username=username, password=password)
        if user is not None:
            django_login(request, user)
            return HttpResponseRedirect("/challenge")
        else:
            return HttpResponseRedirect("/users/login?msg=0&method=login")
    else:
        return HttpResponseBadRequest("Invalid method")


def logout(request):
    django_logout(request)
    return HttpResponseRedirect("/users/login?msg=4&method=login")


def signup(request):
    if request.method == "GET":
        return render(request, "/users/login?method=signup", {})
    elif request.method == "POST":
        name = request.POST.get("name")
        username = request.POST.get("username")
        password = request.POST.get("password")
        passwordConfirm = request.POST.get("passwordConfirm")
        if not (name and username and password and passwordConfirm):
            return HttpResponseRedirect("/users/login?method=signup&msg=1")

        if password != passwordConfirm:
            return HttpResponseRedirect("/users/login?method=signup&msg=2")

        if User.objects.filter(username=username).exists():
            return HttpResponseRedirect("/users/login?method=signup&msg=3")

        first_name = " ".join(name.split(" ")[:-1])[:150]
        last_name = name.split(" ")[-1][:150]
        user = User.objects.create_user(username[:150], password=password, first_name=first_name, last_name=last_name)
        django_login(request, user)
        return HttpResponseRedirect("/challenge")
    else:
        return HttpResponseBadRequest("Invalid method")


@login_required()
def profile(request):
    if request.method == "GET":
        global user_score_cache
        time, scores = user_score_cache.get(request.user.id, (None, None))
        if not time or (datetime.now(timezone.utc) - time).total_seconds() > settings.CACHE_TTL:
            scores = get_user_scores(request.user)
            user_score_cache[request.user.id] = datetime.now(timezone.utc), scores
        flags = get_global_flags(request.user)

        return render(request, "profile.html", {"user": request.user, "submissions": scores, "flags": flags})

    elif request.method == "POST":
        name = request.POST.get("name")
        password = request.POST.get("password")
        passwordConfirm = request.POST.get("passwordConfirm")

        if name:
            request.user.first_name = name

        if password:
            if password != passwordConfirm:
                return HttpResponseRedirect("/users/profile?msg=2")
            request.user.set_password(password)

        if name or password:
            request.user.save()

        return HttpResponseRedirect("/users/profile")
