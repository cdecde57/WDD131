from django.contrib import admin
from .models import Challenge, Submission, UnitTest, UserChallenge, UserFlag


@admin.register(Challenge)
class ChallengeAdmin(admin.ModelAdmin):
    list_display = ('name', 'active', 'created_date')
    list_filter = ('active', 'created_date')
    search_fields = ('name', 'description')
    list_editable = ('active',)


@admin.register(Submission)
class SubmissionAdmin(admin.ModelAdmin):
    list_display = ('job_id', 'user', 'challenge', 'score', 'status', 'created')
    list_filter = ('status', 'challenge', 'created')
    search_fields = ('user__username', 'job_id', 'filehash')
    readonly_fields = ('job_id', 'filehash', 'created')


@admin.register(UnitTest)
class UnitTestAdmin(admin.ModelAdmin):
    list_display = ('submission', 'test_id', 'passed')
    list_filter = ('passed', 'test_id')
    search_fields = ('submission__job_id', 'test_id')


@admin.register(UserChallenge)
class UserChallengeAdmin(admin.ModelAdmin):
    list_display = ('user', 'challenge', 'unlocked')
    list_filter = ('unlocked', 'challenge')
    search_fields = ('user__username', 'challenge__name')
    list_editable = ('unlocked',)
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user', 'challenge')


@admin.register(UserFlag)
class UserFlagAdmin(admin.ModelAdmin):
    list_display = ('user', 'flag2', 'flag3', 'flag2_unlocked_date', 'flag3_unlocked_date')
    list_filter = ('flag2', 'flag3')
    search_fields = ('user__username',)
    readonly_fields = ('flag2_unlocked_date', 'flag3_unlocked_date')
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user')
