import hashlib

from django import forms

from appsecchallenge import settings
from main.models import Status, Submission
from dateutil import tz

local = tz.tzlocal()


def sha(fname):
    hash_sha = hashlib.sha256()
    with open(fname, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_sha.update(chunk)
    return hash_sha.hexdigest()


def get_scores():
    submissions = Submission.objects.filter(status=Status.SCORED.value).select_related('challenge')
    user_challenge_scores = {}
    
    # Get the best score for each user per challenge
    for sub in submissions:
        if sub.score <= 0:
            continue
        user = sub.user.username
        challenge_id = sub.challenge.id if sub.challenge else 'legacy'
        
        if user not in user_challenge_scores:
            user_challenge_scores[user] = {}
        
        if challenge_id not in user_challenge_scores[user]:
            user_challenge_scores[user][challenge_id] = sub.score
        else:
            if sub.score > user_challenge_scores[user][challenge_id]:
                user_challenge_scores[user][challenge_id] = sub.score
    
    # Sum scores across all challenges for each user
    user_total_scores = {}
    for user, challenge_scores in user_challenge_scores.items():
        user_total_scores[user] = sum(challenge_scores.values())
    
    l = [[v, k, 1] for k, v in user_total_scores.items()]
    l.sort(reverse=True)
    prev_score = 1000
    prev_place = 0
    for i in range(len(l)):
        x = l[i]
        score = x[0]
        if prev_score == score:
            place = prev_place
        else:
            place = i + 1
            prev_place = place
            prev_score = score
        x[2] = place
    return l


def get_user_scores(user):
    from main.models import UserFlag
    
    submissions = Submission.objects.filter(user=user).select_related('challenge').all()
    
    # Get user flags (flags are now stored per-user, not per-submission)
    try:
        user_flag = UserFlag.objects.get(user=user)
        flag2 = user_flag.flag2
        flag3 = user_flag.flag3
    except UserFlag.DoesNotExist:
        flag2 = False
        flag3 = False
    
    # Create list with flag values applied to each submission for backwards compatibility
    l = [(s.created.astimezone(local), s.score, s.status, s.filehash, s.job_id, flag2, flag3, s.challenge) for s in submissions]
    l.sort(reverse=True)
    return l


def get_flag(i, filehash):
    if i == 1:
        flag = settings.FLAG_1
    elif i == 2:
        flag = settings.FLAG_2
    elif i == 3:
        flag = settings.FLAG_3
    else:
        flag = ""
    return flag + "-" + str(filehash)


def get_global_flags(user):
    """Get global flags earned by the user"""
    from main.models import UserFlag
    
    submissions = Submission.objects.filter(user=user, status=Status.SCORED.value).select_related('challenge')
    
    flags = []
    
    # Get best score per challenge to determine which submission to use for flag display
    challenge_scores = {}
    
    for sub in submissions:
        if sub.score > 0:
            challenge_id = sub.challenge.id if sub.challenge else 'legacy'
            if challenge_id not in challenge_scores or sub.score > challenge_scores[challenge_id]['score']:
                challenge_scores[challenge_id] = {
                    'score': sub.score,
                    'filehash': sub.filehash
                }
    
    # Get user's unlocked flags from UserFlag model
    try:
        user_flag = UserFlag.objects.get(user=user)
    except UserFlag.DoesNotExist:
        user_flag = None
    
    # Flag 1: Always available based on any completed challenge
    if challenge_scores:
        best_submission = max(challenge_scores.values(), key=lambda x: x['score'])
        flags.append(("Padawan flag:", get_flag(1, best_submission['filehash'])))
    
    # Flag 2: Only show if user has unlocked it
    if user_flag and user_flag.flag2 and challenge_scores:
        best_submission = max(challenge_scores.values(), key=lambda x: x['score'])
        flags.append(("Jedi flag:", get_flag(2, best_submission['filehash'])))
    
    # Flag 3: Only show if user has unlocked it
    if user_flag and user_flag.flag3 and challenge_scores:
        best_submission = max(challenge_scores.values(), key=lambda x: x['score'])
        flags.append(("Master flag:", get_flag(3, best_submission['filehash'])))
    
    return flags


class UploadFileForm(forms.Form):
    file = forms.FileField()
