import os
from models import Submission





def collect_scores():
    pass
