from django.urls import path
from main.views import main, users

urlpatterns = [
    path("", main.index, name="index"),
    path("challenge", main.challenge, name="challenge"),
    path("challenge/submit", main.submit, name="submit"),
    path("scoreboard", main.scoreboard, name="scoreboard"),
    path("scoreboard_2", main.scoreboard_2, name="scoreboard_2"),
    path("users/login", users.login, name="login"),
    path("users/logout", users.logout, name="logout"),
    path("users/signup", users.signup, name="signup"),
    path("users/profile", users.profile, name="profile"),
    path("submissions/<str:submission_id>", main.submission, name="submission"),
]