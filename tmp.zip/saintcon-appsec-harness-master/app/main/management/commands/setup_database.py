"""
Django management command to gracefully set up the database and challenges.
"""
from django.core.management.base import BaseCommand
from django.core.management import call_command
from django.contrib.auth import get_user_model
from django.db import connection
from django.db.utils import OperationalError
import os
import sys


class Command(BaseCommand):
    help = 'Set up database, run migrations, and initialize challenges'

    def add_arguments(self, parser):
        parser.add_argument(
            '--skip-superuser',
            action='store_true',
            help='Skip creating superuser',
        )
        parser.add_argument(
            '--skip-challenges',
            action='store_true',
            help='Skip setting up challenges',
        )

    def handle(self, *args, **options):
        self.stdout.write('=== Database Setup ===')
        
        # Check if database is accessible
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT 1")
            self.stdout.write(self.style.SUCCESS('✓ Database is accessible'))
        except OperationalError as e:
            self.stdout.write(self.style.ERROR(f'Database error: {e}'))
            self.stdout.write('Attempting to create and migrate database...')
            
            # Try to run migrations
            try:
                call_command('migrate', verbosity=1)
                self.stdout.write(self.style.SUCCESS('✓ Database migrations completed'))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Migration failed: {e}'))
                return

        # Ensure migrations are up to date
        try:
            call_command('migrate', verbosity=1)
            self.stdout.write(self.style.SUCCESS('✓ Database migrations up to date'))
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Migration check failed: {e}'))

        # Create superuser if requested
        if not options['skip_superuser']:
            self.create_superuser()

        # Set up challenges if requested  
        if not options['skip_challenges']:
            self.setup_challenges()

        self.stdout.write(self.style.SUCCESS('=== Database setup complete ==='))

    def create_superuser(self):
        """Create default superuser if it doesn't exist"""
        self.stdout.write('\n=== Superuser Setup ===')
        
        User = get_user_model()
        try:
            if not User.objects.filter(username='admin').exists():
                User.objects.create_superuser('admin', 'admin@example.com', 'admin')
                self.stdout.write(self.style.SUCCESS('✓ Superuser created: admin/admin'))
            else:
                self.stdout.write('✓ Superuser already exists')
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Failed to create superuser: {e}'))

    def setup_challenges(self):
        """Set up challenges from YAML configuration"""
        self.stdout.write('\n=== Challenges Setup ===')
        
        # Import setup_challenges functionality
        setup_script_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'setup_challenges.py')
        if os.path.exists(setup_script_path):
            try:
                # Import the setup function
                sys.path.insert(0, os.path.dirname(setup_script_path))
                from setup_challenges import setup_all_challenges
                
                # Redirect the input function to automatically answer 'no' to unlocking challenges
                import builtins
                original_input = builtins.input
                builtins.input = lambda _: 'n'
                
                try:
                    setup_all_challenges()
                    self.stdout.write(self.style.SUCCESS('✓ Challenges setup completed'))
                finally:
                    builtins.input = original_input
                    
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Failed to setup challenges: {e}'))
                self.stdout.write('You can manually run: python setup_challenges.py')
        else:
            self.stdout.write(self.style.WARNING('setup_challenges.py not found - skipping challenge setup'))
            self.stdout.write('You can manually run: python setup_challenges.py')