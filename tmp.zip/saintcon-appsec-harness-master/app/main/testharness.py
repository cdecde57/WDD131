import subprocess
from appsecchallenge import settings
from main.models import Status, Submission, UnitTest, UserFlag
from django_rq import job
from django.utils import timezone
import os
import json
import logging
from main.testcases import get_challenge_config, get_global_flags

logger = logging.getLogger(__name__)


@job
def run(job_id):
    def log(msg, level=logging.INFO):
        logger.log(level, f"{job_id} {msg}")

    def set_result(result, submission):
        log("Setting result")
        if submission:
            submission.status = Status.SCORED.value
            submission.score = result
            submission.save()
            log("Result saved")
        else:
            log("Submission not found", logging.ERROR)
        return result

    def initialize():
        log("initializing job")
        submission = Submission.objects.filter(job_id=job_id).first()
        log(job_id)
        log(submission.filehash)
        if not submission:
            log("Submission not found", logging.ERROR)
            return None

        if not submission.challenge:
            log("No challenge specified for submission", logging.ERROR)
            return None

        submission.status = Status.PENDING.value
        submission.save()
        
        # Get challenge directory name from challenge ID
        challenge_id = submission.challenge.id
        try:
            config = get_challenge_config(challenge_id)
        except KeyError:
            log(f"No configuration found for challenge ID {challenge_id}", logging.ERROR)
            return None
        
        if not config.test_ids:
            log(f"No test IDs configured for challenge ID {challenge_id}", logging.ERROR)
            return None
            
        challenge_path = config.challenge_path
        log(f"Running challenge: {challenge_path} (ID: {challenge_id})")
            
        process = subprocess.run([
            os.path.join(settings.BASE_DIR, "..", "docker", "run-docker.sh"), 
            settings.SUBMISSION_PATH, 
            job_id,
            settings.DOCKER_SHARE, 
            "1" if settings.DEBUG else "0", 
            challenge_path
        ])
        if process.returncode != 0:
            log("Docker run failed", level=logging.ERROR)
            log(f"Return code: {process.returncode}", level=logging.ERROR)
            return submission, False
        return submission, True

    def parse_tests(submission):
        log("scoring tests")
        
        challenge_id = submission.challenge.id
        try:
            config = get_challenge_config(challenge_id)
        except KeyError:
            log(f"No configuration found for challenge ID {challenge_id}", logging.ERROR)
            return 0
        
        if not config.test_ids:
            log(f"No test IDs configured for challenge ID {challenge_id}", logging.ERROR)
            return 0
            
        global_flags_config = get_global_flags()
        
        try:
            with open(os.path.join(settings.RESULTS_PATH, job_id + ".results.json"), "rt") as f:
                results = json.loads(f.read().strip())
                tests = results['tests']

            # Get expected test IDs for this challenge
            expected_test_ids = set(config.test_ids)
            passed_tests = set()
            results_to_save = {}

            # Process each test result
            for test in tests:
                test_id = test['nodeid'].split("::")[-1]
                passed = test['outcome'] == "passed"
                
                if test_id in expected_test_ids and passed:
                    passed_tests.add(test_id)
                
                # Save individual test result
                results_to_save[test_id] = UnitTest(test_id=test_id, submission=submission, passed=passed)

            # Award points only if ALL expected tests passed
            if expected_test_ids == passed_tests:
                score = config.challenge_score
                log(f"Challenge {challenge_id} completed - all {len(expected_test_ids)} tests passed")
                
                # Update user flags if this challenge unlocks any
                user_flag, created = UserFlag.objects.get_or_create(user=submission.user)
                
                if global_flags_config.flag2_challenge_id == challenge_id and not user_flag.flag2:
                    user_flag.flag2 = True
                    user_flag.flag2_unlocked_date = timezone.now()
                    user_flag.save()
                    log(f"Flag 2 unlocked for user {submission.user.username}")
                
                if global_flags_config.flag3_challenge_id == challenge_id and not user_flag.flag3:
                    user_flag.flag3 = True
                    user_flag.flag3_unlocked_date = timezone.now()
                    user_flag.save()
                    log(f"Flag 3 unlocked for user {submission.user.username}")
            else:
                score = 0
                missing_tests = expected_test_ids - passed_tests
                log(f"Challenge {challenge_id} incomplete - passed {len(passed_tests)}/{len(expected_test_ids)} tests")
                if missing_tests:
                    log(f"Failed tests: {missing_tests}")

            UnitTest.objects.bulk_create(results_to_save.values())
            
        except Exception as e:
            log(f"Scoring failed: {e}", logging.ERROR)
            return 0

        log(f"Final score: {score}")
        return score

    submission, success = initialize()
    final_score = None
    if success:
        final_score = parse_tests(submission)
        if final_score is not None:
            set_result(final_score, submission)
    else:
        submission.status = Status.FAILED.value
        submission.save()

    return final_score
