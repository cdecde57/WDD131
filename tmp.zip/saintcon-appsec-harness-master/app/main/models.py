from django.db import models
from django.contrib.auth.models import User
from enum import Enum


class Status(Enum):
    SUBMITTED = 0
    PENDING = 1
    SCORED = 2
    FAILED = 3


class Challenge(models.Model):
    name = models.CharField(max_length=200)
    description = models.TextField()
    repo_url = models.URLField(blank=True, null=True)
    active = models.BooleanField(default=True)
    created_date = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.name


class UserChallenge(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    challenge = models.ForeignKey(Challenge, on_delete=models.CASCADE)
    unlocked = models.BooleanField(default=False)
    
    class Meta:
        unique_together = ('user', 'challenge')
    
    def __str__(self):
        return f"{self.user.username} - {self.challenge.name} ({'Unlocked' if self.unlocked else 'Locked'})"


class UserFlag(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='flags')
    flag2 = models.BooleanField(default=False)
    flag3 = models.BooleanField(default=False)
    flag2_unlocked_date = models.DateTimeField(null=True, blank=True)
    flag3_unlocked_date = models.DateTimeField(null=True, blank=True)
    
    def __str__(self):
        flags = []
        if self.flag2:
            flags.append('Flag2')
        if self.flag3:
            flags.append('Flag3')
        return f"{self.user.username} - {', '.join(flags) if flags else 'No flags'}"


# Create your models here.
class Submission(models.Model):
    job_id = models.UUIDField(primary_key=True)
    # could remove score since that can be calculated from associated UnitTests, but score shouldn't change and this is
    # more efficient
    score = models.IntegerField(default=0)
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING)
    challenge = models.ForeignKey(Challenge, on_delete=models.CASCADE, null=True, blank=True)
    created = models.DateTimeField(auto_now_add=True)
    filehash = models.CharField(max_length=300)
    status = models.IntegerField(default=0)


class UnitTest(models.Model):
    submission = models.ForeignKey(to=Submission, on_delete=models.CASCADE)
    test_id = models.CharField(max_length=100)
    passed = models.BooleanField(default=False)
