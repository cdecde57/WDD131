from __future__ import annotations

import os
import yaml
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Dict, List


@dataclass 
class GlobalFlags:
    flag2_challenge_id: Optional[int] = None
    flag3_challenge_id: Optional[int] = None


@dataclass
class ChallengeConfig:
    id: int
    name: str
    description: str
    repo_url: str
    active: bool
    challenge_score: int
    challenge_path: str
    test_ids: List[str]


def _load_yaml_config() -> tuple[Dict[int, ChallengeConfig], GlobalFlags]:
    """Load challenge configurations from YAML file"""
    config_path = Path(__file__).parent.parent / 'challenges.yaml'
    
    if not config_path.exists():
        raise FileNotFoundError(f"Challenge configuration file not found: {config_path}")
    
    with open(config_path, 'r') as f:
        data = yaml.safe_load(f)
    
    # Parse global flags
    global_flags_data = data.get('global_flags', {})
    global_flags = GlobalFlags(
        flag2_challenge_id=global_flags_data.get('flag2_challenge_id'),
        flag3_challenge_id=global_flags_data.get('flag3_challenge_id')
    )
    
    configs = {}
    
    for challenge_data in data['challenges']:
        # Create challenge config with flattened structure
        config = ChallengeConfig(
            id=challenge_data['id'],
            name=challenge_data['name'],
            description=challenge_data['description'],
            repo_url=challenge_data['repo_url'],
            active=challenge_data['active'],
            challenge_score=challenge_data['challenge_score'],
            challenge_path=challenge_data['challenge_path'],
            test_ids=challenge_data['test_ids']
        )
        
        configs[challenge_data['id']] = config
    
    return configs, global_flags


# Load configurations from YAML
try:
    challenge_configs, global_flags = _load_yaml_config()
except Exception as e:
    print(f"Warning: Failed to load YAML config: {e}")
    # Fallback to empty config
    challenge_configs = {}
    global_flags = GlobalFlags()


def get_challenge_config(challenge_id: int) -> ChallengeConfig:
    """Get test configuration for a specific challenge"""
    return challenge_configs[challenge_id]


def get_all_challenges() -> List[ChallengeConfig]:
    """Get all challenge configurations"""
    return list(challenge_configs.values())


def get_global_flags() -> GlobalFlags:
    """Get global flags configuration"""
    return global_flags