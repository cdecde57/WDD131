#!/usr/bin/env python3
"""
Script to set up all challenges in the database from challenges.yaml configuration.
Run this from the harness app directory: python setup_challenges.py
"""

import os
import sys
import django
from pathlib import Path

# Add the current directory to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Set up Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'appsecchallenge.settings')
django.setup()

from main.models import Challenge, UserChallenge
from main.testcases import get_all_challenges
from django.contrib.auth.models import User

def setup_all_challenges():
    """
    Create or update all challenges from the YAML configuration.
    Also optionally unlock challenges for existing users.
    """
    print("Setting up challenges from challenges.yaml...")
    
    try:
        # Get all challenge configurations from YAML
        challenge_configs = get_all_challenges()
        
        if not challenge_configs:
            print("No challenges found in challenges.yaml")
            return
        
        created_count = 0
        updated_count = 0
        
        for config in challenge_configs:
            # Create or update the challenge in the database
            challenge, created = Challenge.objects.update_or_create(
                id=config.id,
                defaults={
                    'name': config.name,
                    'description': config.description,
                    'repo_url': config.repo_url,
                    'active': config.active
                }
            )
            
            if created:
                created_count += 1
                print(f"✓ Created challenge: {challenge.name} (ID: {challenge.id})")
            else:
                updated_count += 1
                print(f"✓ Updated challenge: {challenge.name} (ID: {challenge.id})")
        
        print(f"\nSummary:")
        print(f"- Created: {created_count} challenges")
        print(f"- Updated: {updated_count} challenges")
        print(f"- Total: {len(challenge_configs)} challenges processed")
        
        # Ask if user wants to unlock challenges for existing users
        unlock_for_users = input("\nUnlock all challenges for existing users? (y/N): ").lower().strip()
        
        if unlock_for_users in ['y', 'yes']:
            unlock_challenges_for_users()
        else:
            print("Challenges not unlocked for users. Use Django admin to manage user access.")
            
    except Exception as e:
        print(f"Error setting up challenges: {e}")
        sys.exit(1)

def unlock_challenges_for_users():
    """
    Unlock all active challenges for all existing users.
    This is mainly for testing/development purposes.
    """
    print("\nUnlocking challenges for users...")
    
    users = User.objects.all()
    active_challenges = Challenge.objects.filter(active=True)
    
    if not users.exists():
        print("No users found in database.")
        return
    
    unlock_count = 0
    
    for user in users:
        for challenge in active_challenges:
            user_challenge, created = UserChallenge.objects.get_or_create(
                user=user,
                challenge=challenge,
                defaults={'unlocked': True}
            )
            
            if created:
                unlock_count += 1
                print(f"  ✓ Unlocked '{challenge.name}' for {user.username}")
            elif not user_challenge.unlocked:
                user_challenge.unlocked = True
                user_challenge.save()
                unlock_count += 1
                print(f"  ✓ Unlocked '{challenge.name}' for {user.username}")
    
    print(f"\nUnlocked {unlock_count} challenge-user combinations")

def list_challenges():
    """
    List all challenges currently in the database.
    """
    print("\nCurrent challenges in database:")
    challenges = Challenge.objects.all().order_by('id')
    
    if not challenges.exists():
        print("No challenges found in database.")
        return
    
    for challenge in challenges:
        status = "🟢 Active" if challenge.active else "🔴 Inactive"
        print(f"  ID {challenge.id}: {challenge.name} - {status}")
        
        # Count users who have this challenge unlocked
        unlocked_count = UserChallenge.objects.filter(challenge=challenge, unlocked=True).count()
        total_users = User.objects.count()
        print(f"    Unlocked for {unlocked_count}/{total_users} users")

def main():
    """
    Main function with command-line argument handling.
    """
    import argparse
    
    parser = argparse.ArgumentParser(description='Manage challenges in the database')
    parser.add_argument('action', nargs='?', default='setup', 
                       choices=['setup', 'list'],
                       help='Action to perform (default: setup)')
    
    args = parser.parse_args()
    
    if args.action == 'list':
        list_challenges()
    else:
        setup_all_challenges()

if __name__ == '__main__':
    main()