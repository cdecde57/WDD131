#!/bin/bash
venv/bin/python manage.py rqworker default
