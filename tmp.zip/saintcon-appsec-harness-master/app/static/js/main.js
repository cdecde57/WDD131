const messages = {
    "0": "Invalid username/password.",
    "1": "Please fill out all fields.",
    "2": "Passwords do not match.",
    "3": "Username in use - please log in or choose a different username.",
    "4": "You have been logged out.",
    "5": "You may only submit once per 5 minutes. Minutes remaining: ",
    "6": "This submission has already been scored.",
    "7": "Your submitted file is too large. Please follow the instructions to create a zip file using the provided script.",
    "8": "Your code has been submitted. Please wait for it to be scored. This can take several minutes. Your flags and scores can be viewed at your profile page by clicking your username.",
    "9": "Invalid file",
    "10": "Please select a valid challenge.",
    "11": "You must submit a file.",
    "12": "Submissions are currently closed. Tests will be posted soon on the github repo linked below.",
    "13": "This challenge has not been unlocked for you yet. Please contact an admin."
}

function getQueryParam(name) {
    const params = new Proxy(new URLSearchParams(window.location.search), {
        get: (searchParams, prop) => searchParams.get(prop),
    });
    return params[name];
}

function setMessage() {
    const id = getQueryParam("msg");
    let message = messages[id];
    if (id == "5") {
        message += (5 - getQueryParam("mins"));
    }
    document.getElementById("notice").textContent = message;
}

function localize() {
    document.querySelectorAll('.date').forEach((e) => {
        const date = new Date(e.getAttribute("data-date"));
        e.innerText = date.toLocaleString();
    });
}

function selectChallenge(challengeId) {
    // Update URL without page reload
    const currentUrl = new URL(window.location);
    currentUrl.searchParams.set('challenge_id', challengeId);
    window.history.pushState({}, '', currentUrl.toString());
    
    // Update UI immediately
    updateSelectedChallenge(challengeId);
}

function updateSelectedChallenge(challengeId) {
    // Remove selection from all cards, but preserve locked styling
    document.querySelectorAll('.challenge-card').forEach(card => {
        const challengeData = card.querySelector('.challenge-data');
        const isUnlocked = challengeData && challengeData.getAttribute('data-unlocked') === 'true';
        
        card.classList.remove('border-warning', 'bg-warning', 'bg-opacity-5');
        
        if (isUnlocked) {
            card.classList.add('border-light', 'bg-white', 'text-dark');
            card.classList.remove('border-secondary', 'bg-secondary', 'bg-opacity-10');
        } else {
            // Restore locked styling
            card.classList.add('border-secondary', 'bg-secondary', 'bg-opacity-10');
            card.classList.remove('border-light', 'bg-white', 'text-dark');
        }
    });
    
    // Add selection to clicked card
    const selectedCard = document.querySelector(`[onclick="selectChallenge(${challengeId})"]`);
    if (selectedCard) {
        selectedCard.classList.remove('border-light', 'bg-white', 'border-secondary', 'bg-secondary', 'bg-opacity-10');
        selectedCard.classList.add('border-warning', 'bg-warning', 'bg-opacity-5');
    }
    
    // Update challenge details and form
    updateChallengeDetails(challengeId);
}

function updateChallengeDetails(challengeId) {
    // Get challenge data from the DOM
    const challengeData = document.querySelector(`.challenge-data[data-id="${challengeId}"]`);
    if (!challengeData) return;
    
    const name = challengeData.getAttribute('data-name');
    const description = challengeData.getAttribute('data-description');
    const repoUrl = challengeData.getAttribute('data-repo-url');
    const unlocked = challengeData.getAttribute('data-unlocked') === 'true';
    
    // Update challenge details section
    document.getElementById('challenge-title').textContent = name;
    document.getElementById('challenge-description').textContent = description;
    
    const repoElement = document.getElementById('challenge-repo');
    const repoLink = document.getElementById('challenge-repo-link');
    if (repoUrl) {
        repoLink.href = repoUrl;
        repoLink.textContent = repoUrl;
        repoElement.style.display = 'block';
    } else {
        repoElement.style.display = 'none';
    }
    
    // Show challenge details
    document.getElementById('challenge-details').style.display = 'block';
    
    // Update submission area based on unlock status
    document.getElementById('submission-form').style.display = unlocked ? 'block' : 'none';
    document.getElementById('challenge-locked').style.display = unlocked ? 'none' : 'block';
    document.getElementById('no-challenge-selected').style.display = 'none';
    
    // Update form
    if (unlocked) {
        document.getElementById('challenge-id-input').value = challengeId;
        document.getElementById('submit-challenge-name').textContent = name;
    }
}