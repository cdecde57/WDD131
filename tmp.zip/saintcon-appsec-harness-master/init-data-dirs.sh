#!/bin/bash
# Initialize data directories for the SAINTCON AppSec Harness

echo "Initializing data directories..."

# Create all required directories
mkdir -p data/{submissions,test-results,docker-share,logs,db,static}

# Set appropriate permissions
chmod 755 data data/*

# Ensure database directory is writable
chmod 777 data/db

echo "Data directories created:"
echo "  data/submissions     - User submissions storage"
echo "  data/test-results    - Test execution results"
echo "  data/docker-share    - Temporary file sharing with containers"
echo "  data/logs           - Application logs"
echo "  data/db             - SQLite database"
echo "  data/static         - Static files"

echo ""
echo "You can now run: docker-compose up --build"