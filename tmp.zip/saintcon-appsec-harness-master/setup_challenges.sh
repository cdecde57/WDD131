#!/bin/bash
# Wrapper script to set up challenges from the harness directory

cd "$(dirname "$0")/app"
python setup_challenges.py "$@"