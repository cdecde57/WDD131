cd /home/app/saintcon-appsec-harness/app
venv/bin/python3 manage.py migrate
uwsgi --reload /tmp/appsecchallenge-master.pid

service nginx restart
service redis restart
service rq restart
