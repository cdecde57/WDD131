#!/bin/bash
# pull repos
cd /home/app/saintcon-appsec-challenge-2024-private
ssh-agent bash -c 'ssh-add /home/app/keys/challenge; git pull; git checkout master'

#cd /home/app/owasp-saintcon-2023-beginner-challenge
#ssh-agent bash -c 'ssh-add /home/app/keys/beginner; git pull; git checkout smanesse-branch'
#docker-compose down
#docker-compose up -d

#cd /home/app/appsec-community-walkthroughs
#git checkout smanesse-deploy-branch; git pull;

cd /home/app/saintcon-appsec-harness
ssh-agent bash -c 'ssh-add /home/app/keys/harness; git pull; git checkout master'

mv /home/app/db.sqlite3 /home/app/saintcon-appsec-harness/app/


#cd /home/app/owasp-saintcon-2023-beginner-challenge
#docker-compose down
#docker-compose up -d

# move files around
echo "moving various files..."
cd /home/app/saintcon-appsec-harness
sudo cp setup/nginx/* /etc/nginx/ -r
sudo rm /etc/nginx/sites-enabled/appsec_nginx.conf.dev
sudo cp setup/redis.conf /etc/redis/
sudo cp setup/*.service /etc/systemd/system/
sudo cp setup/rq.conf /etc/rsyslog.d/
cp /home/app/appconf/local_settings.py /home/app/saintcon-appsec-harness/app/

# python environment
echo "setting up python environment..."
python3 -m venv /home/app/saintcon-appsec-harness/app/venv
/home/app/saintcon-appsec-harness/app/venv/bin/python3 -m pip install -r /home/app/saintcon-appsec-harness/app/requirements.txt

# db migrations
echo "db migrations..."
cd /home/app/saintcon-appsec-harness/app
venv/bin/python3 manage.py migrate

# docker image build
cd /home/app/saintcon-appsec-harness/docker/
#./make-image.sh

# make sure app owns all the right things
sudo chown app /home/app -R
sudo chgrp app /home/app -R

# restart services
sudo systemctl daemon-reload
sudo service redis restart
sudo service uwsgi restart
sudo service rq restart
sudo service nginx restart

#curl https://appsec.saintcon.community/beginner/resetdb.php