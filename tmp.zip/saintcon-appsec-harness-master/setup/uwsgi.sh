uwsgi --chdir=/home/app/saintcon-appsec-harness/app/appsecchallenge \
    --wsgi-file=/home/app/saintcon-appsec-harness/app/appsecchallenge/wsgi.py \
    --env DJANGO_SETTINGS_MODULE=appsecchallenge.settings \
    --master --pidfile=/tmp/appsecchallenge-master.pid \
    --socket=/home/app/run/server.sock \
    --processes=5 \
    --harakiri=20 \
    --max-requests=5000 \
    --vacuum \
    --daemonize=/var/log/appsecchallenge/uwsgi.log
