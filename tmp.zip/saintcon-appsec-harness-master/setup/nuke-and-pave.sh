#!/bin/bash
cd /home/app/
mkdir run
mkdir test-results
sudo mkdir /var/log/appsecchallenge/
sudo chgrp app /var/log/appsecchallenge/
chmod 775 /var/log/appsecchallenge/

rm /home/app/saintcon-appsec-harness /home/app/saintcon-appsec-challenge-2024-private -rf

# clone repos
ssh-agent bash -c 'ssh-add /home/app/keys/harness; git clone git@github.com:smanesse/saintcon-appsec-harness.git'
ssh-agent bash -c 'ssh-add /home/app/keys/challenge; git clone git@github.com:smanesse/saintcon-appsec-challenge-2024-private.git'
ssh-agent bash -c 'ssh-add /home/app/keys/challenge; git clone git@github.com:smanesse/saintcon-appsec-challenge-2024-private.git'

python3 -m venv /home/app/saintcon-appsec-harness/app/venv


/home/app/saintcon-appsec-harness/setup/refresh.sh


