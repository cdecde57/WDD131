#!/bin/bash
# pull repos
echo "replacing repos..."
cd /home/app
mv /home/app/saintcon-appsec-harness/app/db.sqlite3 /home/app/
rm saintcon-appsec-harness -rf
rm saintcon-appsec-challenge-2024-private -rf
cp /mnt/saintcon/saintcon-appsec-harness . -r
cp /mnt/saintcon/challenge ./saintcon-appsec-challenge-2024-private -r
#cp /mnt/saintcon/owasp-saintcon-2024-beginner-challenge . -r
#cp /mnt/saintcon/appsec-community-walkthroughs . -r
mv /home/app/db.sqlite3 /home/app/saintcon-appsec-harness/app/


#cd /home/app/owasp-saintcon-2023-beginner-challenge
#docker-compose down
#docker-compose up -d

# move files around
echo "moving various files..."
cd /home/app/saintcon-appsec-harness
sudo cp setup/nginx/* /etc/nginx/ -r
#mv /etc/nginx/meme.html /var/www/html/meme.html
#mv /etc/nginx/admin.html /var/www/html/admin.html
#chmod 644 /var/www/html/meme.html
sudo mv /etc/nginx/sites-enabled/appsec_nginx.conf.dev /etc/nginx/sites-enabled/appsec_nginx.conf
sudo cp setup/redis.conf /etc/redis/
sudo cp setup/*.service /etc/systemd/system/
sudo cp setup/rq.conf /etc/rsyslog.d/
cp /home/app/appconf/local_settings.py /home/app/saintcon-appsec-harness/app/

# python environment
echo "setting up python environment..."
python3 -m venv /home/app/saintcon-appsec-harness/app/venv
/home/app/saintcon-appsec-harness/app/venv/bin/python3 -m pip install -r /home/app/saintcon-appsec-harness/app/requirements.txt

# db migrations
echo "db migrations..."
cd /home/app/saintcon-appsec-harness/app
venv/bin/python3 manage.py migrate

# docker image build
cd /home/app/saintcon-appsec-harness/docker/
#./make-image.sh

# make sure app owns all the right things
sudo chown app /home/app -R
sudo chgrp app /home/app -R

# restart services
sudo systemctl daemon-reload
sudo service redis restart
sudo service uwsgi restart
sudo service rq restart
sudo service nginx restart

#curl https://appsec.saintcon.community/beginner/resetdb.php