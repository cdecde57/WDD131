#!/bin/bash
pwd
echo "Challenge execution: $1 $2 $3 $4 $5"

SUBMISSION_DIR=$1
JOB_ID=$2
DOCKER_SHARE=$3
TEST_ENV=$4
CHALLENGE=$5

# Setup workspace - create staging area with proper structure
sudo rm -rf "$DOCKER_SHARE"
mkdir -p "$DOCKER_SHARE"
cp "$SUBMISSION_DIR/$JOB_ID" "$DOCKER_SHARE/input.zip"
CHALLENGE_DIR="$DOCKER_SHARE/repo/"

# Create staging area for challenge and tests
mkdir -p "$CHALLENGE_DIR"
mkdir -p "$DOCKER_SHARE/tests"
mkdir -p "$DOCKER_SHARE/results"

# Copy challenge files to staging area
cp "/home/app/saintcon-appsec-challenge-2025-private/$CHALLENGE"/* "$CHALLENGE_DIR" -r

# Copy challenge-specific tests to staging area
echo "Copying challenge tests from: /home/app/saintcon-appsec-challenge-2025-private/$CHALLENGE/tests/"
cp -r "/home/app/saintcon-appsec-challenge-2025-private/$CHALLENGE/tests/"* "$DOCKER_SHARE/tests/"

# Also copy shared test resources (like cleanup.py) to staging area  
echo "Copying shared test resources from: /home/app/saintcon-appsec-challenge-2025-private/tests/"
cp -r "/home/app/saintcon-appsec-challenge-2025-private/tests/"* "$DOCKER_SHARE/tests/" 2>/dev/null || true

echo "Contents of staging tests directory:"
ls -la "$DOCKER_SHARE/tests/"

# Extract user submission
rm -rf /tmp/out/
unzip -o "$DOCKER_SHARE/input.zip" -d /tmp/out

# Copy user submission files to the challenge directory
echo "Copying allowed files for challenge: $CHALLENGE"
cat "/home/app/saintcon-appsec-harness/docker/$CHALLENGE/allowed_files.txt"
while IFS= read -r path; do
    if [ -f "/tmp/out/$path" ]; then
        cp "/tmp/out/$path" "$CHALLENGE_DIR/$path"
        # Set permissions on just the copied file
        chmod 664 "$CHALLENGE_DIR/$path"
        echo "  Copied: $path"
    fi
done < "/home/app/saintcon-appsec-harness/docker/$CHALLENGE/allowed_files.txt"

echo "starting docker container for challenge $CHALLENGE and job ID $2"

# Change to challenge directory
cd "$CHALLENGE_DIR"

pwd
ls -lat

# Set environment variables for docker-compose with absolute paths
# TESTS_CONTEXT points to shared tests (for Dockerfile)
export TESTS_CONTEXT="/home/app/saintcon-appsec-challenge-2025-private/tests"
# TESTS_DIR points to staged challenge-specific tests (for volume mount)
# Convert container path to host path for Docker daemon
# /home/app/run/docker-share -> /home/smanesse/saintcon/2025/saintcon-appsec-harness/data/docker-share
export TESTS_DIR="/home/smanesse/saintcon/2025/saintcon-appsec-harness/data/docker-share/tests"

echo "Running tests with Docker Compose..."
echo "TESTS_CONTEXT=$TESTS_CONTEXT"
echo "TESTS_DIR=$TESTS_DIR"
echo "Current directory: $(pwd)"
echo "Docker-compose file exists: $(test -f docker-compose.yml && echo yes || echo no)"
echo "Host tests directory exists: $(test -d "$TESTS_DIR" && echo yes || echo no)"
echo "Host tests directory contents:"
ls -la "$TESTS_DIR" 2>/dev/null || echo "Directory not accessible"

# Write environment to a file that docker-compose can read
echo "TESTS_CONTEXT=$TESTS_CONTEXT" > .env
echo "TESTS_DIR=$TESTS_DIR" >> .env
echo "Contents of .env file:"
cat .env

sudo -u app docker-compose --profile testing up --build -d

echo "Waiting for tests to complete..."
# Wait for test container to finish with timeout
timeout 60 sudo -u app docker-compose --profile testing wait tests || echo "Test container finished or timed out"
sudo -u app docker-compose --profile testing logs tests

echo "Cleaning up containers..."
sudo -u app docker-compose --profile testing down

# Copy results from shared volume (the test container writes to /shared/out.json)
# We need to extract this from the Docker volume or container
echo "Extracting test results..."
# Create a temporary container to copy results out
docker run --rm -v "${PWD%/*}_shared_results:/shared" -v "$DOCKER_SHARE/results:/host_results" alpine:latest cp /shared/out.json /host_results/ 2>/dev/null || echo "No results found in shared volume"

# Try copying from tests directory as fallback
if [ -f "$DOCKER_SHARE/tests/out.json" ]; then
    cp "$DOCKER_SHARE/tests/out.json" "/home/app/test-results/$JOB_ID.results.json"
elif [ -f "$DOCKER_SHARE/results/out.json" ]; then
    cp "$DOCKER_SHARE/results/out.json" "/home/app/test-results/$JOB_ID.results.json"
else
    echo "Warning: No test results found"
    echo '{"tests": [], "error": "No test results found"}' > "/home/app/test-results/$JOB_ID.results.json"
fi

# Cleanup staging area (but wait a moment for containers to fully stop)
echo "Cleaning up staging area..."
sleep 2
sudo rm -rf "$DOCKER_SHARE"

echo "Challenge execution complete"