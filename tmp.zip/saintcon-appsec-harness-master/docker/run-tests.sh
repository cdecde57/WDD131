#!/bin/bash

cp /mnt/sandbox/repo/test . -r

chown -R appuser .

cd test

pytest --disable-warnings --json-report --json-report-file=/tmp/$JOB_ID.results.json --json-report-omit keywords streams
cp /tmp/$JOB_ID.results.json /mnt/sandbox/$JOB_ID.results.json
