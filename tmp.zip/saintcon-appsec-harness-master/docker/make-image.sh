#!/bin/bash
rm -rf /home/app/sandbox
mkdir /home/app/sandbox
cd /home/app/sandbox
cp /home/app/saintcon-appsec-challenge-2024-private/* . -r
cp /home/app/saintcon-appsec-harness/docker/* . -r
docker build -t apptests .
rm -rf /home/app/sandbox