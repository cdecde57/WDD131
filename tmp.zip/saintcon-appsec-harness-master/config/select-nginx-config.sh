#!/bin/bash
# Remove all configs and install only the appropriate one
rm -f /etc/nginx/sites-enabled/*

if [ "$ENVIRONMENT" = "production" ]; then
    cp /etc/nginx/sites-available/prod /etc/nginx/sites-enabled/default
else
    cp /etc/nginx/sites-available/dev /etc/nginx/sites-enabled/default
fi