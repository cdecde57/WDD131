# Challenge Configuration Guide

This guide explains how to define and configure new challenges for users in the SAINTCON AppSec Harness using the unified YAML configuration system.

## Overview

All challenge configuration is now handled through a single YAML file (`app/challenges.yaml`). This provides:
- **Single source of truth** for all challenge data
- **Version control** of challenge configurations
- **Easy editing** without code changes
- **Consistent structure** across all challenges

## Challenge Configuration File

The main configuration file is located at: `app/challenges.yaml`

### Structure

```yaml
challenges:
  - id: 1                          # Unique challenge ID
    name: "Challenge Name"         # Display name
    description: |                 # Multi-line description
      Challenge description here.
      Can span multiple lines.
    repo_url: "https://..."        # Optional repository URL
    active: true                   # Enable/disable challenge
    flag_2_test_case: "test_id"    # Test case that unlocks Flag 2
    flag_3_test_case: "test_id"    # Test case that unlocks Flag 3
    test_cases:                    # List of test cases
      - id: "test_unique_id"       # Unique test identifier
        name: "Test display name"  # Human readable name
        type: "UNIT"               # "UNIT" or "VULN"
        points: 10                 # Points awarded
        order: 1                   # Display/execution order
        depends_on: "other_test"   # Optional prerequisite test
```

### Test Case Types

- **`UNIT`**: Functional tests that verify application features work correctly
- **`VULN`**: Vulnerability detection tests that award points for finding security issues

### Test Case Fields

| Field | Required | Description |
|-------|----------|-------------|
| `id` | Yes | Unique identifier used in code |
| `name` | Yes | Display name shown to users |
| `type` | Yes | Either "UNIT" or "VULN" |
| `points` | Yes | Points awarded for passing |
| `order` | No | Display/execution order (default: 0) |
| `depends_on` | No | ID of prerequisite test case |

## Adding a New Challenge

1. **Edit `app/challenges.yaml`** - Add a new challenge with unique ID:
   ```yaml
   - id: 4
     name: "Your Challenge Name"
     description: "Challenge description"
     active: true
     flag_2_test_case: "test_for_flag2"
     flag_3_test_case: "test_for_flag3"
     test_cases:
       - id: "test_basic"
         name: "Basic test"
         type: "UNIT"
         points: 10
         order: 1
       - id: "test_for_flag2"
         name: "Vulnerability test"
         type: "VULN" 
         points: 25
         order: 2
   ```

2. **Rebuild**: `docker compose up --build`

3. **Optional**: Manage user access via Django admin at `/admin/main/userchallenge/`

## Managing Existing Challenges

### Enabling/Disabling Challenges

Set `active: true` or `active: false` in the YAML file.

### Modifying Test Cases

Edit the test cases directly in the YAML file. You can:
- Add new test cases
- Modify point values
- Change test case names
- Update dependencies
- Reorder tests by changing the `order` field

### Updating Flag Requirements

Change the `flag_2_test_case` and `flag_3_test_case` values to point to different test case IDs.

## Validation

The system will validate the YAML structure on startup. Common issues:

- **Missing required fields**: All challenges must have `id`, `name`, `description`, `active`, `flag_2_test_case`, `flag_3_test_case`, and `test_cases`
- **Invalid test case types**: Must be "UNIT" or "VULN"
- **Circular dependencies**: A test case cannot depend on itself or create circular references
- **Invalid flag test cases**: The flag test case IDs must exist in the test cases list

## Migration from Old System

The old system mixed database storage with code-based configuration. The new system:

1. **Replaces** the hardcoded test cases in `main/testcases.py`
2. **Maintains compatibility** with existing code that imports from `main.testcases`
3. **Preserves** all existing functionality while providing cleaner configuration

### Backward Compatibility

The system maintains backward compatibility through:
- `get_challenge_config(challenge_id)` function
- Module-level exports: `list_of_cases`, `test_case_map`, `base_score`, etc.
- Same data structures: `TestCase`, `ChallengeConfig`, `TestCaseType`

## Example Challenges

The configuration file includes several example challenges:

1. **SAINTCON 2025 AppSec Challenge** (ID: 1) - The default challenge with multiple language vulnerabilities
2. **Web Application Security Fundamentals** (ID: 2) - Focus on web vulnerabilities
3. **API Security Assessment** (ID: 3) - REST API security testing

## File Locations

- **Configuration**: `app/challenges.yaml`
- **Code**: `app/main/testcases.py`
- **Requirements**: `app/requirements.txt` (includes PyYAML)
- **Dockerfile**: Automatically copies YAML file during build

## Testing Your Configuration

After making changes, you can test the configuration:

```python
# In Django shell: docker compose exec app python manage.py shell
from main.testcases import get_all_challenges, get_challenge_config

# List all challenges
for config in get_all_challenges():
    print(f"ID {config.id}: {config.name} ({len(config.test_cases)} test cases)")

# Get specific challenge
config = get_challenge_config(1)
print(f"Challenge: {config.name}")
print(f"Base score: {config.base_score}")
print(f"Flag 2 test: {config.flag_2_test_case}")
```

## Best Practices

1. **Use descriptive test IDs**: `test_sql_injection_login` vs `test1`
2. **Logical ordering**: Order tests from basic to advanced
3. **Meaningful dependencies**: Only add dependencies that make sense
4. **Balanced scoring**: Award points proportional to difficulty
5. **Clear descriptions**: Help users understand what they're looking for
6. **Version control**: Commit YAML changes with descriptive messages

## Troubleshooting

**YAML syntax errors**: Use a YAML validator or editor with syntax highlighting
**Missing challenges**: Check that the challenge ID exists in the YAML file
**Import errors**: Ensure PyYAML is installed (`pip install PyYAML`)
**File not found**: Verify the YAML file is in the correct location (`app/challenges.yaml`)